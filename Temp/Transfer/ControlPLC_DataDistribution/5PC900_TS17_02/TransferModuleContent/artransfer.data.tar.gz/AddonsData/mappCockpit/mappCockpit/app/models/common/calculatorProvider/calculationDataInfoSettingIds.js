define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var SettingIds = /** @class */ (function () {
        function SettingIds() {
        }
        SettingIds.Type = "type";
        SettingIds.InputDataValues = "inputDataValues";
        SettingIds.InputDataIds = "inputDataIds";
        SettingIds.UniqueId = "uniqueId";
        return SettingIds;
    }());
    exports.SettingIds = SettingIds;
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2FsY3VsYXRpb25EYXRhSW5mb1NldHRpbmdJZHMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBwL21vZGVscy9jb21tb24vY2FsY3VsYXRvclByb3ZpZGVyL2NhbGN1bGF0aW9uRGF0YUluZm9TZXR0aW5nSWRzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztJQUFBO1FBQUE7UUFLQSxDQUFDO1FBSlUsZUFBSSxHQUFHLE1BQU0sQ0FBQztRQUNkLDBCQUFlLEdBQUcsaUJBQWlCLENBQUM7UUFDcEMsdUJBQVksR0FBRyxjQUFjLENBQUM7UUFDOUIsbUJBQVEsR0FBRyxVQUFVLENBQUM7UUFDakMsaUJBQUM7S0FBQSxBQUxELElBS0M7SUFMWSxnQ0FBVSIsInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBjbGFzcyBTZXR0aW5nSWRze1xyXG4gICAgc3RhdGljIFR5cGUgPSBcInR5cGVcIjtcclxuICAgIHN0YXRpYyBJbnB1dERhdGFWYWx1ZXMgPSBcImlucHV0RGF0YVZhbHVlc1wiO1xyXG4gICAgc3RhdGljIElucHV0RGF0YUlkcyA9IFwiaW5wdXREYXRhSWRzXCI7XHJcbiAgICBzdGF0aWMgVW5pcXVlSWQgPSBcInVuaXF1ZUlkXCI7XHJcbn0iXX0=