define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicG9pbnRJbnRlcmZhY2UuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBwL21vZGVscy9jb21tb24vaW50ZXJmYWNlcy9wb2ludEludGVyZmFjZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXHJcbiAqIERlY2xhcmVzIHRoZSBwb2ludCBpbnRlcmZhY2VcclxuICpcclxuICogQGludGVyZmFjZSBJUG9pbnRcclxuICAqL1xyXG5leHBvcnQgaW50ZXJmYWNlIElQb2ludHtcclxuICByZWFkb25seSB4OiBudW1iZXI7XHJcbiAgcmVhZG9ubHkgeTogbnVtYmVyO1xyXG59XHJcbiJdfQ==