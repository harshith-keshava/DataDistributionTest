define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var MathjsVariableDeclaration = /** @class */ (function () {
        function MathjsVariableDeclaration() {
        }
        return MathjsVariableDeclaration;
    }());
    exports.MathjsVariableDeclaration = MathjsVariableDeclaration;
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWF0aGpzVmFyaWFibGVEZWNsYXJhdGlvbi5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uLy4uL3NyYy9hcHAvbW9kZWxzL2NvbW1vbi9zdGF0ZUV4cHJlc3Npb24vY29tbW9uL21hdGhqc1ZhcmlhYmxlRGVjbGFyYXRpb24udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0lBQUE7UUFBQTtRQUlBLENBQUM7UUFBRCxnQ0FBQztJQUFELENBQUMsQUFKRCxJQUlDO0lBRU8sOERBQXlCIiwic291cmNlc0NvbnRlbnQiOlsiY2xhc3MgTWF0aGpzVmFyaWFibGVEZWNsYXJhdGlvbntcclxuICAgIFxyXG4gICAgLy9EdW1teSBjbGFzcyB1c2VkIGZvciByZWFkYWJpbGl0eSBhbmQgZGVwZW5kZWN5IHRyYWNraW5nXHJcbiAgICBbaW5kZXg6IHN0cmluZ106IG51bWJlciB8IG51bGw7XHJcbn1cclxuXHJcbmV4cG9ydCB7TWF0aGpzVmFyaWFibGVEZWNsYXJhdGlvbn07Il19