define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2Nyb2xsU2V0dGluZ3NJbnRlcmZhY2UuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBwL3dpZGdldHMvY29tbW9uL2ludGVyZmFjZXMvc2Nyb2xsU2V0dGluZ3NJbnRlcmZhY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZXNDb250ZW50IjpbImludGVyZmFjZSBJU2Nyb2xsU2V0dGluZ3N7XHJcbiAgICB2ZXJ0aWNhbDogbnVtYmVyO1xyXG4gICAgaG9yaXpvbnRhbDogbnVtYmVyO1xyXG59XHJcblxyXG5leHBvcnQgeyBJU2Nyb2xsU2V0dGluZ3MgfTsiXX0=